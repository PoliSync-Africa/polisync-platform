POLISYNC AFRICA PARTY LOGO ASSETS

Upload these files into:
frontend/public/parties/

Frontend asset paths:
/parties/npp.png  -  New Patriotic Party
/parties/ndc.png  -  National Democratic Congress
/parties/cpp.png  -  Convention People's Party
/parties/gum.png  -  Ghana Union Movement
/parties/bise.png  -  BISE Movement
/parties/ppp.png  -  Progressive People's Party
/parties/lpg.png  -  Liberal Party of Ghana
/parties/gfp.png  -  Ghana Freedom Party
/parties/up.png  -  United Party
/parties/new-force.png  -  The New Force
/parties/eyc-kube.png  -  EYC KUBƐ
/parties/independent.png  -  Independent